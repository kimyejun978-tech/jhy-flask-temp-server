package app.devfeed.mobile;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DevFeedNotificationJobService extends JobService {
    private static final String API = "https://devfeed-api.kimyejun978.workers.dev";
    private static final String CHANNEL_ID = "devfeed_updates";
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();

    @Override public boolean onStartJob(JobParameters params) {
        EXECUTOR.execute(() -> {
            try { runCheck(); } catch (Exception ignored) {}
            jobFinished(params, false);
        });
        return true;
    }
    @Override public boolean onStopJob(JobParameters params) { return true; }

    private void runCheck() throws Exception {
        JSONObject prefs = getJson("/v1/preferences");
        JSONArray events = getItems("/v1/events");
        JSONArray trends = getItems("/v1/trends");
        JSONArray news = getItems("/v1/ai-news");

        SharedPreferences sp = getSharedPreferences("devfeed_native_notifications", MODE_PRIVATE);
        Set<String> eventSeen = copySet(sp.getStringSet("events", new HashSet<>()));
        Set<String> trendSeen = copySet(sp.getStringSet("trends", new HashSet<>()));
        Set<String> newsSeen = copySet(sp.getStringSet("news", new HashSet<>()));
        boolean baseline = sp.getBoolean("baseline", false);

        if (!baseline) {
            addIds(events, eventSeen); addIds(trends, trendSeen); addIds(news, newsSeen);
            sp.edit().putStringSet("events", eventSeen).putStringSet("trends", trendSeen).putStringSet("news", newsSeen).putBoolean("baseline", true).apply();
            return;
        }

        int sent = 0;
        if (prefs.optBoolean("eventsEnabled", true)) sent += notifyNewEvents(events, eventSeen, 3);
        if (prefs.optBoolean("trendsEnabled", true) && sent < 4) sent += notifyNewTrends(trends, trendSeen, 4 - sent);
        if (prefs.optBoolean("newsEnabled", true) && sent < 5) sent += notifyNewNews(news, newsSeen, 5 - sent);
        notifyReminders(events, prefs, sp);

        addIds(events, eventSeen); addIds(trends, trendSeen); addIds(news, newsSeen);
        sp.edit().putStringSet("events", eventSeen).putStringSet("trends", trendSeen).putStringSet("news", newsSeen).apply();
    }

    private int notifyNewEvents(JSONArray items, Set<String> seen, int limit) {
        int count = 0;
        for (int i = 0; i < items.length() && count < limit; i++) {
            JSONObject item = items.optJSONObject(i); if (item == null) continue;
            String id = clean(item, "id"); if (id.isEmpty() || seen.contains(id)) continue;
            String title = clean(item, "title"); if (title.isEmpty()) continue;
            String meta = eventMeta(item);
            post("새 행사 · DevFeed", title, meta, "event:" + id);
            count++;
        }
        return count;
    }

    private int notifyNewTrends(JSONArray items, Set<String> seen, int limit) {
        int count = 0;
        for (int i = 0; i < items.length() && count < limit; i++) {
            JSONObject item = items.optJSONObject(i); if (item == null) continue;
            String id = clean(item, "id"); if (id.isEmpty() || seen.contains(id)) continue;
            if (!"HIGH".equalsIgnoreCase(clean(item, "importance"))) continue;
            String title = clean(item, "title"); if (title.isEmpty()) continue;
            post("주요 개발 트렌드", title, clean(item, "summary"), "trend:" + id);
            count++;
        }
        return count;
    }

    private int notifyNewNews(JSONArray items, Set<String> seen, int limit) {
        int count = 0;
        for (int i = 0; i < items.length() && count < limit; i++) {
            JSONObject item = items.optJSONObject(i); if (item == null) continue;
            String id = clean(item, "id"); if (id.isEmpty() || seen.contains(id)) continue;
            String title = clean(item, "title"); if (title.isEmpty()) continue;
            post("조코딩 AI 뉴스", title, "새 AI 뉴스 요약이 도착했어요.", "news:" + id);
            count++;
        }
        return count;
    }

    private void notifyReminders(JSONArray events, JSONObject prefs, SharedPreferences sp) {
        long now = System.currentTimeMillis();
        for (int i = 0; i < events.length(); i++) {
            JSONObject item = events.optJSONObject(i); if (item == null) continue;
            String id = clean(item, "id"); String title = clean(item, "title"); if (id.isEmpty() || title.isEmpty()) continue;
            Long deadline = parseTime(clean(item, "deadline"));
            Long start = parseTime(clean(item, "startDate"));
            if (deadline != null) {
                long diff = deadline - now;
                if (prefs.optBoolean("deadline3Enabled", true) && inHours(diff, 70, 74)) remindOnce(sp, "d3:"+id, "신청 마감 3일 전", title);
                if (prefs.optBoolean("deadline1Enabled", true) && inHours(diff, 22, 26)) remindOnce(sp, "d1:"+id, "신청 마감 하루 전", title);
            }
            if (start != null && prefs.optBoolean("eventDayBeforeEnabled", true) && inHours(start-now, 22, 26)) remindOnce(sp, "e1:"+id, "행사 하루 전", title);
        }
    }

    private void remindOnce(SharedPreferences sp, String key, String heading, String title) {
        if (sp.getBoolean(key, false)) return;
        post(heading, title, "DevFeed에서 일정과 공식 링크를 확인해보세요.", "reminder:"+key);
        sp.edit().putBoolean(key, true).apply();
    }

    private static boolean inHours(long ms, int min, int max) { long h = ms / 3600000L; return h >= min && h <= max; }

    private JSONArray getItems(String path) throws Exception { JSONObject root = getJson(path); JSONArray a = root.optJSONArray("items"); return a == null ? new JSONArray() : a; }
    private JSONObject getJson(String path) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(API + path).openConnection();
        c.setConnectTimeout(10000); c.setReadTimeout(15000); c.setRequestMethod("GET"); c.setRequestProperty("Accept", "application/json"); c.setRequestProperty("x-user-id", "local-default");
        int code = c.getResponseCode(); if (code < 200 || code >= 300) { c.disconnect(); throw new IllegalStateException("HTTP "+code); }
        StringBuilder b = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()))) { String line; while ((line=r.readLine())!=null) b.append(line); }
        finally { c.disconnect(); }
        return new JSONObject(b.toString());
    }

    private void post(String heading, String title, String text, String key) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE); if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel(CHANNEL_ID, "DevFeed 알림", NotificationManager.IMPORTANCE_DEFAULT));
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        PendingIntent pi = null;
        if (launch != null) { launch.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP); pi = PendingIntent.getActivity(this, key.hashCode(), launch, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE); }
        String body = text == null || text.trim().isEmpty() ? title : title + "\n" + text.trim();
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(heading).setContentText(body).setStyle(new Notification.BigTextStyle().bigText(body)).setAutoCancel(true).setOnlyAlertOnce(true);
        if (pi != null) builder.setContentIntent(pi);
        nm.notify(key.hashCode(), builder.build());
    }

    private static String eventMeta(JSONObject item) {
        List<String> parts = new ArrayList<>(); String date = formatDate(clean(item, "startDate")); String location = item.optBoolean("isOnline", false) ? "온라인" : clean(item, "location");
        if (!date.isEmpty()) parts.add(date); if (!location.isEmpty()) parts.add(location); String deadline = formatDate(clean(item, "deadline")); if (!deadline.isEmpty()) parts.add("마감 " + deadline);
        return join(parts, " · ");
    }
    private static String formatDate(String value) { if (value == null || value.length() < 10 || "null".equalsIgnoreCase(value)) return ""; if (value.charAt(4)=='-' && value.charAt(7)=='-') return value.substring(5,7)+"/"+value.substring(8,10); return value; }
    private static String clean(JSONObject o, String key) { if (o == null || o.isNull(key)) return ""; String s=o.optString(key, "").trim(); return "null".equalsIgnoreCase(s) ? "" : s; }
    private static String join(List<String> list, String sep) { StringBuilder b=new StringBuilder(); for(String s:list){ if(b.length()>0)b.append(sep); b.append(s);} return b.toString(); }
    private static Set<String> copySet(Set<String> source) { return source == null ? new HashSet<>() : new HashSet<>(source); }
    private static void addIds(JSONArray items, Set<String> target) { for(int i=0;i<items.length();i++){ JSONObject o=items.optJSONObject(i); String id=clean(o,"id"); if(!id.isEmpty())target.add(id);} }

    private static Long parseTime(String value) {
        if (value == null || value.isEmpty()) return null;
        String[] patterns = {"yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ss", "yyyy-MM-dd"};
        for (String pattern : patterns) {
            try { SimpleDateFormat f = new SimpleDateFormat(pattern, Locale.US); f.setLenient(false); if (!pattern.contains("XXX")) f.setTimeZone(TimeZone.getTimeZone("Asia/Seoul")); Date d=f.parse(value); if(d!=null)return d.getTime(); } catch(Exception ignored) {}
        }
        return null;
    }
}
