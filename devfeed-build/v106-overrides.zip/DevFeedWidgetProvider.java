package app.devfeed.mobile;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DevFeedWidgetProvider extends AppWidgetProvider {
    private static final String API_URL = "https://devfeed-api.kimyejun978.workers.dev/v1/events";
    private static final String ACTION_REFRESH = "app.devfeed.mobile.action.REFRESH_WIDGET";
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();

    @Override public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (AppWidgetManager.ACTION_APPWIDGET_UPDATE.equals(action) || ACTION_REFRESH.equals(action)) {
            PendingResult result = goAsync(); Context app = context.getApplicationContext();
            EXECUTOR.execute(() -> { try { updateAllWidgets(app); } finally { result.finish(); } });
            return;
        }
        super.onReceive(context, intent);
    }

    private static void updateAllWidgets(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context); ComponentName component = new ComponentName(context, DevFeedWidgetProvider.class); int[] ids = manager.getAppWidgetIds(component); if (ids == null || ids.length == 0) return;
        List<EventRow> rows = new ArrayList<>(); int total = 0;
        try { FetchResult result = fetchEvents(); rows = result.rows; total = result.total; } catch (Exception ignored) {}
        for (int widgetId : ids) { RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.devfeed_widget); bindInteractions(context, views); bindRows(views, rows, total); manager.updateAppWidget(widgetId, views); }
    }

    private static void bindInteractions(Context context, RemoteViews views) {
        Intent refresh = new Intent(context, DevFeedWidgetProvider.class).setAction(ACTION_REFRESH);
        views.setOnClickPendingIntent(R.id.widget_refresh, PendingIntent.getBroadcast(context, 501, refresh, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        Intent launch = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        if (launch != null) { launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP); views.setOnClickPendingIntent(R.id.widget_root, PendingIntent.getActivity(context, 502, launch, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE)); }
    }

    private static void bindRows(RemoteViews views, List<EventRow> rows, int total) {
        if (rows.isEmpty()) {
            views.setTextViewText(R.id.widget_event_1, "행사를 불러오지 못했어요"); views.setTextViewText(R.id.widget_meta_1, "새로고침 버튼을 눌러 다시 확인"); views.setViewVisibility(R.id.widget_deadline_1, View.GONE);
            views.setTextViewText(R.id.widget_event_2, "DevFeed가 검증된 행사를 모으는 중"); views.setTextViewText(R.id.widget_meta_2, ""); views.setViewVisibility(R.id.widget_deadline_2, View.GONE); views.setTextViewText(R.id.widget_status, "네트워크 연결을 확인해주세요"); return;
        }
        bindOne(views, rows.get(0), true);
        if (rows.size() > 1) bindOne(views, rows.get(1), false); else { views.setTextViewText(R.id.widget_event_2, "새 행사 확인 중"); views.setTextViewText(R.id.widget_meta_2, "ChatGPT가 계속 찾아볼게요"); views.setViewVisibility(R.id.widget_deadline_2, View.GONE); }
        views.setTextViewText(R.id.widget_status, "검증된 행사 " + total + "개 · 30분마다 갱신");
    }

    private static void bindOne(RemoteViews views, EventRow row, boolean first) {
        int titleId = first ? R.id.widget_event_1 : R.id.widget_event_2; int metaId = first ? R.id.widget_meta_1 : R.id.widget_meta_2; int deadlineId = first ? R.id.widget_deadline_1 : R.id.widget_deadline_2;
        views.setTextViewText(titleId, row.title); views.setTextViewText(metaId, row.meta);
        if (row.deadline.isEmpty()) views.setViewVisibility(deadlineId, View.GONE); else { views.setViewVisibility(deadlineId, View.VISIBLE); views.setTextViewText(deadlineId, row.deadline); }
    }

    private static FetchResult fetchEvents() throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(API_URL).openConnection(); c.setConnectTimeout(8000); c.setReadTimeout(10000); c.setRequestMethod("GET"); c.setRequestProperty("Accept", "application/json"); c.setRequestProperty("x-user-id", "local-default");
        int status = c.getResponseCode(); if (status < 200 || status >= 300) { c.disconnect(); throw new IllegalStateException("HTTP "+status); }
        StringBuilder body = new StringBuilder(); try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()))) { String line; while((line=r.readLine())!=null)body.append(line); } finally { c.disconnect(); }
        JSONArray items = new JSONObject(body.toString()).optJSONArray("items"); List<EventRow> all = new ArrayList<>(); if(items==null)return new FetchResult(all,0);
        for(int i=0;i<items.length();i++){ JSONObject item=items.optJSONObject(i); if(item==null)continue; String id=clean(item,"id"); if(id.startsWith("sample-"))continue; String title=clean(item,"title"); if(title.isEmpty())continue; String start=clean(item,"startDate"); String location=item.optBoolean("isOnline",false)?"온라인":clean(item,"location"); String meta=buildMeta(start,location); String deadline=deadlineLabel(clean(item,"deadline")); all.add(new EventRow(title,meta,deadline,parseTime(start))); }
        Collections.sort(all, new Comparator<EventRow>() { @Override public int compare(EventRow a, EventRow b) { if(a.time==null&&b.time==null)return 0; if(a.time==null)return 1; if(b.time==null)return -1; return Long.compare(a.time,b.time); }});
        List<EventRow> top = new ArrayList<>(); long today = System.currentTimeMillis() - 12L*60L*60L*1000L; for(EventRow r:all){ if(r.time==null||r.time>=today){ top.add(r); if(top.size()==2)break; }} if(top.size()<2){ for(EventRow r:all){ if(!top.contains(r)){ top.add(r); if(top.size()==2)break; } } }
        return new FetchResult(top, all.size());
    }

    private static String buildMeta(String dateValue,String place){ List<String> p=new ArrayList<>(); String date=friendlyDate(dateValue); if(!date.isEmpty())p.add(date); if(place!=null&&!place.trim().isEmpty()&&!"null".equalsIgnoreCase(place.trim()))p.add(place.trim()); return join(p," · "); }
    private static String friendlyDate(String v){ Long t=parseTime(v); if(t==null)return ""; long days=(startOfDay(t)-startOfDay(System.currentTimeMillis()))/86400000L; if(days==0)return "오늘"; if(days==1)return "내일"; SimpleDateFormat f=new SimpleDateFormat("M/d (E)", Locale.KOREAN); f.setTimeZone(TimeZone.getTimeZone("Asia/Seoul")); return f.format(new Date(t)); }
    private static String deadlineLabel(String v){ Long t=parseTime(v); if(t==null)return ""; long days=(startOfDay(t)-startOfDay(System.currentTimeMillis()))/86400000L; if(days<0)return "마감"; if(days==0)return "오늘 마감"; if(days<=30)return "D-"+days; SimpleDateFormat f=new SimpleDateFormat("M/d 마감",Locale.KOREAN); f.setTimeZone(TimeZone.getTimeZone("Asia/Seoul")); return f.format(new Date(t)); }
    private static long startOfDay(long t){ java.util.Calendar c=java.util.Calendar.getInstance(TimeZone.getTimeZone("Asia/Seoul")); c.setTimeInMillis(t); c.set(java.util.Calendar.HOUR_OF_DAY,0); c.set(java.util.Calendar.MINUTE,0); c.set(java.util.Calendar.SECOND,0); c.set(java.util.Calendar.MILLISECOND,0); return c.getTimeInMillis(); }
    private static Long parseTime(String value){ if(value==null||value.isEmpty()||"null".equalsIgnoreCase(value))return null; String[] patterns={"yyyy-MM-dd'T'HH:mm:ssXXX","yyyy-MM-dd'T'HH:mm:ss.SSSXXX","yyyy-MM-dd'T'HH:mm:ss","yyyy-MM-dd"}; for(String pattern:patterns){ try{ SimpleDateFormat f=new SimpleDateFormat(pattern,Locale.US); f.setLenient(false); if(!pattern.contains("XXX"))f.setTimeZone(TimeZone.getTimeZone("Asia/Seoul")); Date d=f.parse(value); if(d!=null)return d.getTime(); }catch(Exception ignored){} } return null; }
    private static String clean(JSONObject o,String key){ if(o==null||o.isNull(key))return ""; String s=o.optString(key,"").trim(); return "null".equalsIgnoreCase(s)?"":s; }
    private static String join(List<String> p,String sep){ StringBuilder b=new StringBuilder(); for(String s:p){ if(b.length()>0)b.append(sep); b.append(s);} return b.toString(); }
    private static final class EventRow { final String title,meta,deadline; final Long time; EventRow(String t,String m,String d,Long ti){title=t;meta=m;deadline=d;time=ti;} }
    private static final class FetchResult { final List<EventRow> rows; final int total; FetchResult(List<EventRow> r,int t){rows=r;total=t;} }
}
